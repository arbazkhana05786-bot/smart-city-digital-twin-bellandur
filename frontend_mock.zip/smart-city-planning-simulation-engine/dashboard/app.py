"""
Smart City Planning and Simulation Engine (Bengaluru Base)
Stage 1: Frontend Command Hub & Simulation Orchestrator
Focused on Outer Ring Road (ORR) - Bellandur - Devarabisanahalli Corridor.
"""

import sys
from pathlib import Path
import yaml
import streamlit as st

# Setup import paths
APP_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = APP_DIR.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# Simulation and Model Imports
from simulation_engine.graph_loader import GraphLoader
from simulation_engine.dynamic_penalizer import DynamicPenalizer
from simulation_engine.adaptive_signal_controller import AdaptiveSignalController
from simulation_engine.anomaly_speed_detector import AnomalySpeedDetector
from simulation_engine.ambulance_router import AmbulanceRouter
from simulation_engine.evacuation_router import EvacuationRouter

from models.inference.vision_detector import MockVisionDetector
from models.inference.disaster_predictor import MockDisasterPredictor
from models.inference.fire_spread_ca import MockFireSpreadCA

from dashboard.components.map_renderer import MapRenderer
from dashboard.components.control_panel import ControlPanel
from dashboard.components.action_card import ActionCardRenderer
from dashboard.components.citizen_feed import CitizenFeedRenderer

# -----------------------------------------------------------------------------
# Streamlit Page Setup
# -----------------------------------------------------------------------------
st.set_page_config(
    page_title="BLR Smart City Command Hub — Bellandur / ORR",
    page_icon="🏙️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling for Slate Theme (#0F172A)
st.markdown(
    """
    <style>
    /* Dark Slate Theme Overrides */
    .stApp {
        background-color: #0F172A !important;
        color: #F8FAFC !important;
        font-family: 'Inter', -apple-system, sans-serif !important;
    }
    
    header[data-testid="stHeader"] {
        background-color: #0F172A !important;
    }
    
    section[data-testid="stSidebar"] {
        background-color: #1E293B !important;
        border-right: 1px solid #334155 !important;
    }
    
    /* Metric Cards */
    div[data-testid="stMetric"] {
        background: #1E293B;
        border: 1px solid #334155;
        border-radius: 10px;
        padding: 10px 14px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    div[data-testid="stMetricLabel"] {
        font-size: 11px !important;
        color: #94A3B8 !important;
        font-weight: 700 !important;
        text-transform: uppercase !important;
    }
    div[data-testid="stMetricValue"] {
        font-size: 19px !important;
        color: #FFFFFF !important;
        font-weight: 800 !important;
    }
    
    /* Buttons */
    .stButton > button {
        background: #334155 !important;
        color: #FFFFFF !important;
        border: 1px solid #475569 !important;
        border-radius: 8px !important;
        font-weight: 600 !important;
        transition: all 0.2s ease !important;
    }
    .stButton > button:hover {
        background: #475569 !important;
        border-color: #38BDF8 !important;
        color: #38BDF8 !important;
    }

    /* Sliders and widgets */
    .stSlider > div {
        color: #F8FAFC !important;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# -----------------------------------------------------------------------------
# Initialize Engine Modules (Cached for speed)
# -----------------------------------------------------------------------------
@st.cache_resource
def init_services():
    data_dir = PROJECT_ROOT / "data" / "osm_graphs"
    loader = GraphLoader(data_dir)
    network = loader.load_network()
    buildings = loader.load_buildings()

    with open(PROJECT_ROOT / "config" / "settings.yaml", "r", encoding="utf-8") as f:
        settings = yaml.safe_load(f)

    penalizer = DynamicPenalizer()
    signals = AdaptiveSignalController()
    speed_detector = AnomalySpeedDetector()
    amb_router = AmbulanceRouter()
    evac_router = EvacuationRouter()

    vision = MockVisionDetector()
    disaster_pred = MockDisasterPredictor()
    fire_ca = MockFireSpreadCA()

    return {
        "loader": loader,
        "network": network,
        "buildings": buildings,
        "settings": settings,
        "penalizer": penalizer,
        "signals": signals,
        "speed_detector": speed_detector,
        "amb_router": amb_router,
        "evac_router": evac_router,
        "vision": vision,
        "disaster_pred": disaster_pred,
        "fire_ca": fire_ca
    }

services = init_services()
network = services["network"]
buildings = services["buildings"]

# Component instances
control_panel = ControlPanel()
map_renderer = MapRenderer(services["settings"])
action_renderer = ActionCardRenderer()
feed_renderer = CitizenFeedRenderer()

# -----------------------------------------------------------------------------
# Sidebar: Control Panel
# -----------------------------------------------------------------------------
sim_inputs = control_panel.render_controls()
rainfall_mm = sim_inputs["rainfall_mm"]
fire_active = sim_inputs["fire_active"]
wind_speed_kmh = sim_inputs["wind_speed_kmh"]
wind_direction_deg = sim_inputs["wind_direction_deg"]
seismic_magnitude = sim_inputs["seismic_magnitude"]
speed_anomaly = sim_inputs["speed_anomaly"]
custom_speed = sim_inputs["custom_speed"]
ems_green_wave = sim_inputs["ems_green_wave"]

# -----------------------------------------------------------------------------
# Simulation State Processing
# -----------------------------------------------------------------------------
# 1. Disaster Risk Assessment
risk_data = services["disaster_pred"].calculate_multihazard_risk(
    rainfall_mm=rainfall_mm,
    wind_speed_kmh=wind_speed_kmh,
    seismic_magnitude=seismic_magnitude
)

# 2. Dynamic Penalization of Network Edges
is_underpass_flooded = rainfall_mm >= 45.0
penalized_edges = services["penalizer"].penalize_network(
    edges=network.get("edges", []),
    rainfall_mm=rainfall_mm,
    fire_active=fire_active,
    speed_anomaly_active=speed_anomaly,
    force_underpass_block=is_underpass_flooded
)

# 3. Anomaly Speed Detection
speed_eval = services["speed_detector"].evaluate_edge_speeds(
    edges=penalized_edges,
    simulated_drop_active=speed_anomaly,
    custom_anomaly_speed_kmh=custom_speed
)

# 4. Adaptive Traffic Signals
signal_states = services["signals"].get_signal_states(
    ems_override_active=ems_green_wave,
    flood_active=is_underpass_flooded,
    fire_active=fire_active
)

# 5. EMS Route & Detour Pathing
# If action card approved or automated bypass: prefer flyover
ems_route = services["amb_router"].compute_ems_route(
    underpass_blocked=is_underpass_flooded,
    fire_active=fire_active,
    speed_anomaly_active=speed_anomaly
)

# 6. Fire Spread CA Geometry
fire_info = services["fire_ca"].simulate_spread_polygon(
    fire_active=fire_active,
    wind_speed_kmh=wind_speed_kmh,
    wind_direction_deg=wind_direction_deg
)

# 7. Evacuation Routing
evac_plan = services["evac_router"].compute_evacuation_plan(
    hazard_type="FIRE" if fire_active else ("SEISMIC" if seismic_magnitude >= 4.5 else "NORMAL")
)

# -----------------------------------------------------------------------------
# Top Command Header & KPI Metrics Bar
# -----------------------------------------------------------------------------
st.markdown(
    """
    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #334155; padding-bottom:12px; margin-bottom:14px;">
        <div>
            <div style="display:flex; align-items:center; gap:8px;">
                <span style="font-size:24px;">🏛️</span>
                <h1 style="margin:0; font-size:22px; font-weight:800; color:#FFFFFF;">BENGALURU SMART CITY COMMAND HUB</h1>
                <span style="background:rgba(16,185,129,0.2); color:#10B981; border:1px solid #10B981; padding:3px 9px; border-radius:99px; font-size:11px; font-weight:800;">STAGE 1 LIVE MOCK</span>
            </div>
            <p style="margin:2px 0 0 0; font-size:12px; color:#94A3B8;">Sector 4: Outer Ring Road (ORR) • Bellandur Junction • Ecospace • Sakra Trauma Hub</p>
        </div>
        <div style="text-align:right;">
            <span style="font-size:11px; color:#64748B;">BBMP Emergency Dispatch Sync</span>
            <div style="font-size:13px; font-weight:700; color:#38BDF8;">🟢 Online • 14 Monitored Nodes</div>
        </div>
    </div>
    """,
    unsafe_allow_html=True
)

m1, m2, m3, m4, m5 = st.columns(5)
with m1:
    threat_color = "normal" if risk_data["threat_level"] == "NOMINAL" else "inverse"
    st.metric(
        "Threat Index",
        f"{risk_data['composite_risk_score']:.0f}/100",
        delta=risk_data["threat_level"],
        delta_color=threat_color
    )
with m2:
    underpass_status = "Submerged (Red)" if is_underpass_flooded else "Passable"
    st.metric(
        "Bellandur Underpass",
        underpass_status,
        delta=f"{rainfall_mm:.0f} mm/hr" if is_underpass_flooded else "Dry Corridor",
        delta_color="inverse" if is_underpass_flooded else "normal"
    )
with m3:
    st.metric(
        "EMS Corridor",
        "Detour Active" if ems_route["is_detour"] else "Optimal Direct",
        delta=f"ETA: {ems_route['est_time_min']} min",
        delta_color="normal"
    )
with m4:
    speed_status = f"{custom_speed:.0f} km/h (Deadlock)" if speed_anomaly else "40 - 55 km/h"
    st.metric(
        "Corridor Velocity",
        speed_status,
        delta="-100% Collapse" if speed_anomaly else "Nominal Flow",
        delta_color="inverse" if speed_anomaly else "normal"
    )
with m5:
    st.metric(
        "Signal Wave",
        "FORCED EMS GREEN" if ems_green_wave else "Adaptive Cycle",
        delta="120s Preemption" if ems_green_wave else "Normal Density",
        delta_color="normal"
    )

st.markdown("<div style='height:8px;'></div>", unsafe_allow_html=True)

# -------------------------------------------------------------
# Main Visualization & Dashboard Layout
# -------------------------------------------------------------
col_map, col_ops = st.columns([68, 32])

with col_map:
    # 3D PyDeck Map Rendering
    deck = map_renderer.create_deck(
        buildings_geojson=buildings,
        edges=penalized_edges,
        ems_route_info=ems_route,
        rainfall_mm=rainfall_mm,
        fire_info=fire_info,
        seismic_magnitude=seismic_magnitude,
        signal_states=signal_states,
        assembly_grounds=evac_plan.get("all_assembly_grounds")
    )

    st.pydeck_chart(deck, use_container_width=True)

    # Interactive Map Visual Legend & Status Badges
    st.markdown(
        """
        <div style="background:#1E293B; border:1px solid #334155; border-radius:10px; padding:10px 14px; margin-top:8px; display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:10px; font-size:12px;">
            <div style="display:flex; align-items:center; gap:6px;">
                <span style="display:inline-block; width:12px; height:12px; background:#EF4444; border-radius:2px;"></span>
                <span style="color:#FFFFFF; font-weight:700;">Impassable / Flooded (Red)</span>
            </div>
            <div style="display:flex; align-items:center; gap:6px;">
                <span style="display:inline-block; width:12px; height:12px; background:#10B981; border-radius:2px;"></span>
                <span style="color:#FFFFFF; font-weight:700;">Active EMS Detour (Green)</span>
            </div>
            <div style="display:flex; align-items:center; gap:6px;">
                <span style="display:inline-block; width:12px; height:12px; background:#38BDF8; border-radius:2px;"></span>
                <span style="color:#FFFFFF; font-weight:700;">Rising Flood Plane (Blue)</span>
            </div>
            <div style="display:flex; align-items:center; gap:6px;">
                <span style="display:inline-block; width:12px; height:12px; background:#F97316; border-radius:2px;"></span>
                <span style="color:#FFFFFF; font-weight:700;">Fire Spread Zone (Orange)</span>
            </div>
            <div style="display:flex; align-items:center; gap:6px;">
                <span style="display:inline-block; width:12px; height:12px; background:#A855F7; border-radius:2px;"></span>
                <span style="color:#FFFFFF; font-weight:700;">Assembly Shelter (Purple)</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Sub-card: Vision Detection AI & Camera Validator
    st.markdown("<div style='height:12px;'></div>", unsafe_allow_html=True)
    with st.expander("📷 Edge-AI Vision Stream & CCTV Detector (Bellandur Underpass Sensor CAM-04)", expanded=is_underpass_flooded):
        vision_res = services["vision"].detect_hazards("cam_bellandur_underpass", simulated_rainfall_mm=rainfall_mm)
        v_col1, v_col2 = st.columns([1, 2])
        with v_col1:
            st.markdown(
                f"""
                <div style="background:#0F172A; border:1px solid #334155; border-radius:8px; padding:12px; text-align:center;">
                    <div style="font-size:32px;">📹</div>
                    <div style="font-size:12px; font-weight:700; color:#38BDF8;">FEED: CAM-04-ORR</div>
                    <div style="font-size:11px; color:#94A3B8;">Bellandur Underpass S/W</div>
                    <div style="margin-top:6px; font-size:11px; font-weight:800; color:{'#EF4444' if vision_res['is_road_compromised'] else '#10B981'};">
                        STATUS: {'COMPROMISED' if vision_res['is_road_compromised'] else 'NORMAL'}
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )
        with v_col2:
            st.markdown(f"**Inference Model:** `{vision_res['model_version']}`")
            for det in vision_res["detections"]:
                st.markdown(
                    f"- **Hazard Detected:** `{det['label']}` (Confidence: **{det['confidence']*100:.1f}%**) • Severity: **{det['severity']}**"
                )
                if "water_depth_est_cm" in det:
                    st.markdown(f"- **Estimated Water Depth:** `{det['water_depth_est_cm']} cm` (Action: `{det['recommended_status']}`)")

with col_ops:
    # 1. Action Cards (Human-Centered Decision Directives)
    action_renderer.render_action_cards(
        risk_data=risk_data,
        ems_route=ems_route,
        fire_active=fire_active,
        seismic_magnitude=seismic_magnitude,
        speed_anomaly=speed_anomaly,
        rainfall_mm=rainfall_mm
    )

    st.markdown("<hr style='border:none; border-top:1px solid #334155; margin:14px 0;'/>", unsafe_allow_html=True)

    # 2. Adaptive Traffic Signal Controller Status
    st.markdown(
        """
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:8px;">
            <h4 style="margin:0; font-size:15px; font-weight:800; color:#FFFFFF;">🚦 Adaptive Signal Nodes</h4>
            <span style="font-size:11px; color:#38BDF8;">Green Wave Status</span>
        </div>
        """,
        unsafe_allow_html=True
    )
    for sig in signal_states[:3]:
        lamp_badge = (
            f"<span style='background:rgba(16,185,129,0.2); color:#10B981; border:1px solid #10B981; padding:2px 6px; border-radius:4px; font-size:10px; font-weight:800;'>{sig['current_lamp']}</span>"
            if "GREEN" in sig['current_lamp'] else
            f"<span style='background:rgba(239,68,68,0.2); color:#EF4444; border:1px solid #EF4444; padding:2px 6px; border-radius:4px; font-size:10px; font-weight:800;'>{sig['current_lamp']}</span>"
        )
        st.markdown(
            f"""
            <div style="background:#1E293B; border:1px solid #334155; border-radius:8px; padding:8px 12px; margin-bottom:6px; display:flex; justify-content:space-between; align-items:center;">
                <div>
                    <div style="font-size:12px; font-weight:700; color:#FFFFFF;">{sig['name']}</div>
                    <div style="font-size:10.5px; color:#94A3B8;">Cycle: Green {sig['green_duration_sec']}s / Red {sig['red_duration_sec']}s</div>
                </div>
                {lamp_badge}
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("<hr style='border:none; border-top:1px solid #334155; margin:14px 0;'/>", unsafe_allow_html=True)

    # 3. Citizen Feed Component
    feed_renderer.render_feed(rainfall_mm=rainfall_mm, speed_anomaly=speed_anomaly)

    # Link to Citizen PWA
    st.markdown(
        """
        <div style="background:rgba(15,23,42,0.8); border:1px dashed #38BDF8; border-radius:10px; padding:12px; text-align:center; margin-top:10px;">
            <div style="font-size:12px; font-weight:800; color:#38BDF8;">📲 Citizen Web PWA Form</div>
            <div style="font-size:11px; color:#94A3B8; margin:4px 0 8px 0;">3-Tap Emergency Reporter (Mobile Optimized)</div>
            <a href="http://localhost:8502" target="_blank" style="display:inline-block; background:#38BDF8; color:#0F172A; font-size:12px; font-weight:800; text-decoration:none; padding:6px 14px; border-radius:6px;">
                Open Citizen PWA ↗
            </a>
        </div>
        """,
        unsafe_allow_html=True
    )
