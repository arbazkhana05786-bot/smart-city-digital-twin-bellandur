"""
Map Renderer Component - Stage 1 Frontend
PyDeck 3D Map Visualizer for Bengaluru Bellandur / ORR Corridor.
Renders 3D extruded buildings, rising blue flood planes, road network geometries,
emergency detour paths, fire hazard perimeters, and safe assembly grounds.
"""

from typing import Dict, Any, List
import pydeck as pdk


class MapRenderer:
    """Constructs PyDeck Deck with custom 3D and vector hazard layers."""

    def __init__(self, settings: Dict[str, Any]):
        self.settings = settings
        self.center_lat = 12.9268
        self.center_lon = 77.6815
        self.zoom = 14.3
        self.pitch = 52.0
        self.bearing = -18.0

    def create_deck(
        self,
        buildings_geojson: Dict[str, Any],
        edges: List[Dict[str, Any]],
        ems_route_info: Dict[str, Any],
        rainfall_mm: float = 0.0,
        fire_info: Dict[str, Any] = None,
        seismic_magnitude: float = 0.0,
        signal_states: List[Dict[str, Any]] = None,
        assembly_grounds: List[Dict[str, Any]] = None
    ) -> pdk.Deck:
        """
        Assemble PyDeck layers dynamically based on current simulation state.
        """
        layers = []

        # -------------------------------------------------------------
        # 1. 3D Building Layer (Extruded Buildings)
        # -------------------------------------------------------------
        # Parse buildings feature collection into polygon data
        bldg_data = []
        for feat in buildings_geojson.get("features", []):
            props = feat.get("properties", {})
            geom = feat.get("geometry", {})
            coords = geom.get("coordinates", [])

            # Determine color by type & seismic risk
            b_type = props.get("type", "commercial_office")
            if b_type == "hospital":
                color = [244, 63, 94, 230] # Rose / Medical Red
            elif b_type == "emergency_service":
                color = [16, 185, 129, 230] # Emerald
            elif b_type == "residential":
                color = [100, 116, 139, 210] # Slate
            else:
                color = [56, 189, 248, 200] # Cyan / Tech Park

            # Seismic jitter / alert tint
            height = props.get("height", 30.0)
            if seismic_magnitude >= 5.0 and props.get("structural_risk") in ["high", "medium"]:
                color = [239, 68, 68, 240]

            if coords:
                bldg_data.append({
                    "name": props.get("name", "Building"),
                    "height": height * 1.5, # Exaggerate height for striking 3D aesthetic
                    "color": color,
                    "polygon": coords[0],
                    "occupancy": props.get("occupancy", 1000),
                    "elevation": props.get("elevation", 882.0)
                })

        building_layer = pdk.Layer(
            "PolygonLayer",
            bldg_data,
            id="3d-buildings-layer",
            get_polygon="polygon",
            get_elevation="height",
            get_fill_color="color",
            get_line_color=[255, 255, 255, 80],
            line_width_min_pixels=1,
            extruded=True,
            wireframe=True,
            pickable=True,
            auto_highlight=True
        )
        layers.append(building_layer)

        # -------------------------------------------------------------
        # 2. Rising Flood Water Inundation Polygon Layer (Bellandur Depression Zone)
        # -------------------------------------------------------------
        # When rain slider moves, water plane rises and expands over low-elevation basin
        if rainfall_mm >= 30.0:
            flood_alpha = min(210, int(90 + (rainfall_mm - 30.0) * 1.6))
            flood_elevation_m = max(5.0, (rainfall_mm - 30.0) * 0.4)

            # Inundation basin polygon centered around Bellandur underpass & lake inlet
            flood_basin_coords = [
                [77.6710, 12.9230],
                [77.6800, 12.9240],
                [77.6825, 12.9275],
                [77.6765, 12.9295],
                [77.6715, 12.9270],
                [77.6710, 12.9230]
            ]

            flood_data = [{
                "name": f"Bellandur Flood Plane (Rainfall: {rainfall_mm:.0f}mm)",
                "polygon": flood_basin_coords,
                "elevation": flood_elevation_m,
                "color": [14, 165, 233, flood_alpha], # Electric Water Blue
                "depth_info": f"{((rainfall_mm - 30.0) * 0.75):.1f} cm waterlogged"
            }]

            flood_layer = pdk.Layer(
                "PolygonLayer",
                flood_data,
                id="flood-inundation-layer",
                get_polygon="polygon",
                get_elevation="elevation",
                get_fill_color="color",
                get_line_color=[56, 189, 248, 250],
                line_width_min_pixels=2,
                extruded=True,
                pickable=True
            )
            layers.append(flood_layer)

        # -------------------------------------------------------------
        # 3. Base Road Network Layer (Paths)
        # -------------------------------------------------------------
        road_paths = []
        for edge in edges:
            coords = edge.get("path_coords", [])
            if coords:
                is_blocked = edge.get("is_blocked", False)
                # Impassable roads glow bright emergency red; regular roads stay neutral
                color = edge.get("color", [148, 163, 184, 180])
                width = 8 if is_blocked else 4

                road_paths.append({
                    "name": edge.get("name", "Road Link"),
                    "path": coords,
                    "color": color,
                    "width": width,
                    "status": edge.get("status_text", "CLEAR"),
                    "speed": f"{edge.get('effective_speed_kmh', 40.0):.0f} km/h"
                })

        road_layer = pdk.Layer(
            "PathLayer",
            road_paths,
            id="road-network-layer",
            get_path="path",
            get_color="color",
            get_width="width",
            width_min_pixels=3,
            width_max_pixels=10,
            pickable=True,
            rounded=True
        )
        layers.append(road_layer)

        # -------------------------------------------------------------
        # 4. Active EMS Corridor / Detour Bypass Layer
        # -------------------------------------------------------------
        if ems_route_info and ems_route_info.get("path_coords"):
            ems_path_data = [{
                "name": ems_route_info.get("route_name", "EMS Corridor"),
                "path": ems_route_info.get("path_coords"),
                "color": ems_route_info.get("color", [16, 185, 129, 255]),
                "width": 10,
                "status": ems_route_info.get("status_badge", "ACTIVE"),
                "eta": f"{ems_route_info.get('est_time_min', 5.0):.1f} min"
            }]

            ems_layer = pdk.Layer(
                "PathLayer",
                ems_path_data,
                id="ems-corridor-layer",
                get_path="path",
                get_color="color",
                get_width=10,
                width_min_pixels=5,
                width_max_pixels=14,
                pickable=True,
                rounded=True
            )
            layers.append(ems_layer)

        # -------------------------------------------------------------
        # 5. Fire CA Hazard Boundary Rings (Orange/Amber)
        # -------------------------------------------------------------
        if fire_info and fire_info.get("fire_active") and fire_info.get("rings"):
            fire_data = []
            for ring in fire_info["rings"]:
                fire_data.append({
                    "name": f"Fire Boundary ({ring.get('ring_name')})",
                    "polygon": ring.get("polygon"),
                    "color": ring.get("color", [249, 115, 22, 180])
                })

            fire_layer = pdk.Layer(
                "PolygonLayer",
                fire_data,
                id="fire-spread-ca-layer",
                get_polygon="polygon",
                get_fill_color="color",
                get_line_color=[255, 237, 213, 220],
                line_width_min_pixels=2,
                extruded=False,
                pickable=True
            )
            layers.append(fire_layer)

        # -------------------------------------------------------------
        # 6. Safe Assembly Grounds & Medical Nodes (Point Layer)
        # -------------------------------------------------------------
        point_markers = []
        if assembly_grounds:
            for g in assembly_grounds:
                point_markers.append({
                    "name": g.get("name"),
                    "coordinates": [g.get("lon"), g.get("lat")],
                    "color": [168, 85, 247, 240], # Purple shelter icon
                    "radius": 55,
                    "info": f"Capacity: {g.get('current_count')}/{g.get('max_capacity')} Sheltered"
                })

        # Add Sakra Hospital Anchor
        point_markers.append({
            "name": "Sakra World Hospital (EMS Destination)",
            "coordinates": [77.6875, 12.9282],
            "color": [244, 63, 94, 255], # Red Cross
            "radius": 65,
            "info": "Level-1 Trauma & Emergency Care Hub"
        })

        # Add Iblur Origin
        point_markers.append({
            "name": "Iblur EMS Dispatch Base",
            "coordinates": [77.6655, 12.9208],
            "color": [16, 185, 129, 255],
            "radius": 50,
            "info": "Rapid Response Ambulance Station"
        })

        if point_markers:
            points_layer = pdk.Layer(
                "ScatterplotLayer",
                point_markers,
                id="key-markers-layer",
                get_position="coordinates",
                get_fill_color="color",
                get_radius="radius",
                radius_min_pixels=6,
                radius_max_pixels=16,
                pickable=True
            )
            layers.append(points_layer)

        # -------------------------------------------------------------
        # 7. Adaptive Traffic Signals Overlay
        # -------------------------------------------------------------
        if signal_states:
            sig_data = []
            for sig in signal_states:
                sig_data.append({
                    "name": f"Signal: {sig.get('name')}",
                    "coordinates": [sig.get("lon"), sig.get("lat")],
                    "color": sig.get("color_rgb", [34, 197, 94]) + [255],
                    "radius": 32,
                    "info": f"Mode: {sig.get('mode')} | Green: {sig.get('green_duration_sec')}s | Red: {sig.get('red_duration_sec')}s"
                })

            signals_layer = pdk.Layer(
                "ScatterplotLayer",
                sig_data,
                id="traffic-signals-layer",
                get_position="coordinates",
                get_fill_color="color",
                get_radius="radius",
                radius_min_pixels=5,
                radius_max_pixels=10,
                pickable=True
            )
            layers.append(signals_layer)

        # Seismic jitter effect on view state if active
        pitch = self.pitch
        bearing = self.bearing
        if seismic_magnitude >= 4.5:
            pitch += 2.5
            bearing += 3.0

        view_state = pdk.ViewState(
            latitude=self.center_lat,
            longitude=self.center_lon,
            zoom=self.zoom,
            pitch=pitch,
            bearing=bearing
        )

        tooltip = {
            "html": "<div style='font-family:Inter,sans-serif; font-size:12px; color:#F8FAFC; background:#1E293B; padding:8px; border-radius:6px; border:1px solid #334155;'>"
                    "<b>{name}</b><br/>"
                    "<span style='color:#38BDF8;'>{status}</span> {info} {depth_info}"
                    "</div>",
            "style": {"backgroundColor": "transparent", "color": "white"}
        }

        deck = pdk.Deck(
            layers=layers,
            initial_view_state=view_state,
            tooltip=tooltip,
            map_style="mapbox://styles/mapbox/dark-v10"
        )

        return deck
