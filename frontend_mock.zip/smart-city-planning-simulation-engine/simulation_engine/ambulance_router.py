"""
Ambulance Router (EMS Geometry Detour Routing Engine) - Stage 1 Frontend
Computes primary and emergency bypass detour geometries for ambulances heading towards
Sakra World Hospital or Manipal Hospital Bellandur when primary service roads become impassable.
"""

from typing import Dict, Any, List


class AmbulanceRouter:
    """Calculates active EMS corridors, primary trajectories, and hazard-evasive detour paths."""

    def __init__(self):
        # Primary direct route: Iblur -> Bellandur Underpass -> Ecospace -> Sakra Hospital
        self.primary_route_coords = [
            [77.6655, 12.9208], # Iblur Junction (Start)
            [77.6710, 12.9235], # Bellandur Gate
            [77.6765, 12.9262], # Bellandur Underpass (Low elevation chokepoint)
            [77.6842, 12.9250], # Ecospace Gate
            [77.6875, 12.9282]  # Sakra World Hospital Access (Destination)
        ]

        # Resilient elevated flyover route: Iblur -> Bellandur Elevated Flyover -> Sakra Hospital
        self.elevated_bypass_coords = [
            [77.6655, 12.9208], # Iblur Junction
            [77.6710, 12.9235], # Bellandur Gate
            [77.6770, 12.9265], # Bellandur Elevated Flyover Crest (Overpasses flood water)
            [77.6842, 12.9250], # Ecospace
            [77.6875, 12.9282]  # Sakra Hospital
        ]

        # Full Sarjapur - Panathur Detour Bypass: Iblur -> Sarjapur Rd -> Doddakannelli -> Panathur -> Sakra
        self.sarjapur_detour_coords = [
            [77.6655, 12.9208], # Iblur
            [77.6685, 12.9175],
            [77.6720, 12.9150], # Sarjapur Road Mid
            [77.6800, 12.9140],
            [77.6890, 12.9135], # Doddakannelli
            [77.6940, 12.9210],
            [77.6995, 12.9290], # Panathur Link
            [77.6955, 12.9355], # Kadubeesanahalli
            [77.6905, 12.9305], # Devarabisanahalli
            [77.6875, 12.9282]  # Sakra World Hospital
        ]

    def compute_ems_route(
        self,
        underpass_blocked: bool = False,
        fire_active: bool = False,
        speed_anomaly_active: bool = False,
        prefer_flyover: bool = True
    ) -> Dict[str, Any]:
        """
        Compute optimal EMS path. If hazards exist, returns detour geometry with visual color coding.
        """
        needs_detour = underpass_blocked or fire_active or speed_anomaly_active

        if not needs_detour:
            return {
                "route_type": "PRIMARY_DIRECT",
                "route_name": "ORR Service Corridor Direct to Sakra Hospital",
                "is_detour": False,
                "distance_km": 2.55,
                "est_time_min": 5.2,
                "path_coords": self.primary_route_coords,
                "color": [16, 185, 129, 240], # Emerald green
                "status_badge": "OPTIMAL DIRECT",
                "hazard_warning": None,
                "waypoints_count": len(self.primary_route_coords),
                "detour_explanation": "Direct ORR lane open. No severe waterlogging detected."
            }

        # If detour is needed:
        if fire_active:
            # Fire at Ecospace blocks flyover descent too; take outer Sarjapur bypass
            chosen_path = self.sarjapur_detour_coords
            route_name = "Sarjapur - Doddakannelli - Panathur Outer Bypass"
            distance_km = 6.4
            est_time_min = 12.8
            delay_added_min = 7.6
            color = [56, 189, 248, 240] # Electric cyan
            reason = "Ecospace fire perimeter active. Direct ORR corridor cordoned off."
        else:
            # Flood or speed anomaly at underpass: take Bellandur Flyover or Sarjapur
            if prefer_flyover:
                chosen_path = self.elevated_bypass_coords
                route_name = "Bellandur Elevated Flyover Bypass (+2.1 min)"
                distance_km = 2.85
                est_time_min = 7.3
                delay_added_min = 2.1
                color = [16, 185, 129, 240] # Vibrant green
                reason = "Bellandur Underpass submerged (>30cm). Traffic routed onto elevated flyover lane."
            else:
                chosen_path = self.sarjapur_detour_coords
                route_name = "Sarjapur Arterial Bypass Detour (+4.2 min)"
                distance_km = 4.9
                est_time_min = 9.4
                delay_added_min = 4.2
                color = [56, 189, 248, 240]
                reason = "Severe ORR choke. Rerouting via Sarjapur arterial bypass corridor."

        return {
            "route_type": "EMERGENCY_DETOUR",
            "route_name": route_name,
            "is_detour": True,
            "distance_km": round(distance_km, 2),
            "est_time_min": round(est_time_min, 1),
            "delay_added_min": round(delay_added_min, 1),
            "path_coords": chosen_path,
            "color": color,
            "blocked_segment_coords": self.primary_route_coords[1:3], # Segment where flood / choke is
            "status_badge": "HAZARD DETOUR ACTIVE",
            "hazard_warning": "PRIMARY CHOKEPOINT DETECTED",
            "waypoints_count": len(chosen_path),
            "detour_explanation": reason
        }


if __name__ == "__main__":
    router = AmbulanceRouter()
    print("Normal:", router.compute_ems_route(False)["route_name"])
    print("Blocked:", router.compute_ems_route(True)["route_name"])
