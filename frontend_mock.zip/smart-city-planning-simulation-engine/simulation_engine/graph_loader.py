"""
Graph Loader (Network & GeoJSON Parser) - Stage 1 Frontend
Loads Bengaluru Bellandur / ORR road network graph and 3D building polygons from cached JSON assets.
"""

import json
from pathlib import Path
from typing import Dict, Any, List, Optional


class GraphLoader:
    """Parses and manages road network graphs and building footprints."""

    def __init__(self, base_dir: Optional[Path] = None):
        if base_dir is None:
            # Relative to this file: ../data/osm_graphs
            base_dir = Path(__file__).resolve().parent.parent / "data" / "osm_graphs"
        self.base_dir = Path(base_dir)
        self.network_file = self.base_dir / "bengaluru_bellandur_network.json"
        self.buildings_file = self.base_dir / "bengaluru_buildings.geojson"

        self._network_cache: Optional[Dict[str, Any]] = None
        self._buildings_cache: Optional[Dict[str, Any]] = None

    def load_network(self) -> Dict[str, Any]:
        """Load and cache the Bellandur road network."""
        if self._network_cache is None:
            if not self.network_file.exists():
                raise FileNotFoundError(f"Network file not found at {self.network_file}")
            with open(self.network_file, "r", encoding="utf-8") as f:
                self._network_cache = json.load(f)
        return self._network_cache

    def load_buildings(self) -> Dict[str, Any]:
        """Load and cache the building GeoJSON collection."""
        if self._buildings_cache is None:
            if not self.buildings_file.exists():
                raise FileNotFoundError(f"Buildings file not found at {self.buildings_file}")
            with open(self.buildings_file, "r", encoding="utf-8") as f:
                self._buildings_cache = json.load(f)
        return self._buildings_cache

    def get_nodes(self) -> List[Dict[str, Any]]:
        network = self.load_network()
        return network.get("nodes", [])

    def get_edges(self) -> List[Dict[str, Any]]:
        network = self.load_network()
        return network.get("edges", [])

    def get_node_by_id(self, node_id: str) -> Optional[Dict[str, Any]]:
        for n in self.get_nodes():
            if n.get("id") == node_id:
                return n
        return None

    def get_edge_by_id(self, edge_id: str) -> Optional[Dict[str, Any]]:
        for e in self.get_edges():
            if e.get("id") == edge_id:
                return e
        return None


if __name__ == "__main__":
    loader = GraphLoader()
    net = loader.load_network()
    bldgs = loader.load_buildings()
    print(f"Loaded {len(net['nodes'])} nodes, {len(net['edges'])} edges.")
    print(f"Loaded {len(bldgs['features'])} buildings.")
