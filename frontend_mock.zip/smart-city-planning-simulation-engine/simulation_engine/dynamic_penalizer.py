"""
Dynamic Penalizer (Edge-Disaster Intersection Engine) - Stage 1 Frontend
Evaluates real-time disaster interactions with road edges and assigns dynamic travel-time penalties,
blockages, and visual color statuses for map rendering.
"""

from typing import Dict, Any, List


class DynamicPenalizer:
    """Calculates hazard-induced edge impedances and passable/impassable route states."""

    def __init__(self):
        # Color definitions [R, G, B, A]
        self.COLOR_NORMAL = [148, 163, 184, 180]     # Slate blue/gray
        self.COLOR_IMPASSABLE = [239, 68, 68, 240]   # Bright emergency red
        self.COLOR_WARNING = [245, 158, 11, 210]     # Amber warning
        self.COLOR_ACTIVE_EMS = [16, 185, 129, 240]  # Vibrant green/cyan
        self.COLOR_DETOUR = [56, 189, 248, 220]      # Electric cyan bypass

    def penalize_network(
        self,
        edges: List[Dict[str, Any]],
        rainfall_mm: float = 0.0,
        fire_active: bool = False,
        speed_anomaly_active: bool = False,
        force_underpass_block: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Evaluate every road edge against active hazard conditions and return enriched edge states.
        """
        penalized_edges = []

        for edge in edges:
            edge_copy = dict(edge)
            distance_m = edge_copy.get("distance_m", 1000)
            base_speed_kmh = edge_copy.get("base_speed_kmh", 40.0)

            # Default status
            is_blocked = False
            status_text = "CLEAR"
            penalty_multiplier = 1.0
            color = list(self.COLOR_NORMAL)

            # 1. Flood Inundation Check (e.g. Bellandur Underpass)
            threshold = edge_copy.get("flood_threshold_rainfall_mm", 999.0)
            if edge_copy.get("vulnerable_to_flood", False) and (rainfall_mm >= threshold or force_underpass_block):
                is_blocked = True
                status_text = "IMPASSABLE_FLOODED"
                penalty_multiplier = 999.0
                color = list(self.COLOR_IMPASSABLE)

            # 2. Fire Proximity Check
            # Ecospace access edges affected if fire is raging
            elif fire_active and "ecospace" in edge_copy.get("id", ""):
                is_blocked = True
                status_text = "BLOCKED_FIRE_ZONE"
                penalty_multiplier = 50.0
                color = list(self.COLOR_IMPASSABLE)

            # 3. Speed Anomaly Check (Simulated Drop 40km/h -> 0km/h)
            elif speed_anomaly_active and ("underpass" in edge_copy.get("id", "") or "sakra" in edge_copy.get("id", "")):
                is_blocked = True
                status_text = "GRIDLOCK_ANOMALY"
                penalty_multiplier = 100.0
                color = list(self.COLOR_IMPASSABLE)

            # 4. Elevated Flyover Resilience Check
            elif "flyover_elevated" in edge_copy.get("id", ""):
                # If underpass is blocked, main elevated flyover or bypass stays active
                if rainfall_mm >= 45.0 or force_underpass_block:
                    status_text = "ACTIVE_BYPASS_CORRIDOR"
                    color = list(self.COLOR_DETOUR)
                    penalty_multiplier = 0.9

            # 5. Sarjapur Bypass Arterial
            elif "sarjapur" in edge_copy.get("id", "") or "panathur" in edge_copy.get("id", ""):
                if rainfall_mm >= 45.0 or speed_anomaly_active:
                    status_text = "RECOMMENDED_DETOUR"
                    color = list(self.COLOR_ACTIVE_EMS)

            # Calculate dynamic travel time
            current_speed = 0.1 if is_blocked else (base_speed_kmh / penalty_multiplier)
            travel_time_sec = (distance_m / 1000.0) / (current_speed / 3600.0)

            edge_copy["is_blocked"] = is_blocked
            edge_copy["status_text"] = status_text
            edge_copy["penalty_multiplier"] = penalty_multiplier
            edge_copy["color"] = color
            edge_copy["effective_speed_kmh"] = round(current_speed, 1)
            edge_copy["effective_travel_time_sec"] = round(travel_time_sec, 1)

            penalized_edges.append(edge_copy)

        return penalized_edges


if __name__ == "__main__":
    penalizer = DynamicPenalizer()
    dummy_edges = [
        {"id": "edge_bellandur_underpass", "vulnerable_to_flood": True, "flood_threshold_rainfall_mm": 45.0, "distance_m": 800, "base_speed_kmh": 40.0},
        {"id": "edge_sarjapur_bypass", "vulnerable_to_flood": False, "flood_threshold_rainfall_mm": 999.0, "distance_m": 1200, "base_speed_kmh": 45.0}
    ]
    res = penalizer.penalize_network(dummy_edges, rainfall_mm=60.0)
    for e in res:
        print(f"{e['id']}: blocked={e['is_blocked']}, status={e['status_text']}, color={e['color']}")
